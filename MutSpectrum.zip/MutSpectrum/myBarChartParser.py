#!/usr/bin/env python

import fileinput
import os
import os.path
from os import path
import glob

# GUI layout



# data parsing for R read.table function
def parser():
    g = open('dFLUXcategoryGlobal.txt', 'w')
    l = open('dFLUXcategoryLocal.txt', 'w')
    g.write("dFLUX  type\n")
    l.write("dFLUX  type\n")
    for foldername in os.listdir(os.getcwd()):
        if (foldername) == 'myBarChartParser.py':
            continue
        elif (foldername) == 'dFLUXcategoryGlobal.txt':
            continue 
        elif (foldername) == 'dFLUXcategoryLocal.txt':
            continue
        elif (foldername) == 'BarChart.r':
            continue
        elif (foldername) == 'Rplots.pdf':
            continue
        print (foldername)
        for filename in os.listdir(foldername):
            print (filename)
            my_path = path.join(foldername, filename)
            for line in fileinput.input(files = (my_path)):
                #print (line.strip())
                dataRow = line.strip()
                print(dataRow)
                data = dataRow.split()
                #print(data[6])
                #dFLUX = data[6]  # abs dFLUX
                dFLUX = data[5]  # signed dFLUX
                position = data[0]
                AAq = data[1]
                AAr = data[2]
                #g.write('%r\t%r\n' % (dFLUX, foldername))
                if position != 'pos_ref':
                    g.write(dFLUX)
                    g.write('\t')
                    g.write(foldername)
                    g.write('\n')
                if position != 'pos_ref' and AAq != AAr:   
                    l.write(dFLUX)
                    l.write('\t')
                    l.write(foldername)
                    l.write('\n')
parser()


# calling R to run ggplot2
def callR():
    import subprocess
    command = 'Rscript'
    path2script = 'BarChart.r'
    cmd = [command, path2script]
    x = subprocess.check_output(cmd, universal_newlines = True)
    print (x)
callR()

#end script
print ("end myBarChartParser.py")
exit;