
print("hello Greg...welcome to R")

library('ggplot2')
dataG = read.table('dFLUXcategoryGlobal.txt', header = TRUE)
dataL = read.table('dFLUXcategoryLocal.txt', header = TRUE)
dFLUX_global = dataG$dFLUX; # abs delta fluctuation
category_global = dataG$type; # category
dFLUX_local = dataL$dFLUX; # abs delta fluctuation
category_local = dataL$type; # category

dG = data.frame(deltaFLUX1=dFLUX_global, MUTtype1=factor(category_global))
dL = data.frame(deltaFLUX2=dFLUX_local, MUTtype2=factor(category_local))
myplot1 <- ggplot(dataG, mapping = aes(x = category_global, y = dFLUX_global)) + geom_boxplot() + labs(x = 'genetic or epigenetic mutation category', y = 'abs dFLUX - entire backbone') + theme(axis.text.x=element_text(angle=15), panel.background = element_rect(fill = 'grey50'))
myplot2 <- ggplot(data = dL, mapping = aes(x = MUTtype2, y = deltaFLUX2)) + geom_boxplot() + labs(x = 'genetic or epigenetic mutation category', y = 'abs dFLUX - site of mutation') + theme(axis.text.x=element_text(angle=15), panel.background = element_rect(fill = 'grey50'))
mytest1A <- oneway.test(dFLUX_global~category_global)
mytest1B <- pairwise.t.test(dFLUX_global, category_global, p.adj = "bonf")
print (mytest1A)
print (mytest1B)
mytest2A <- oneway.test (dFLUX_local~category_local)
mytest2B <- pairwise.t.test(dFLUX_local, category_local, p.adj = "bonf")
print (mytest2A)
print (mytest2B)
library('grid')
pushViewport(viewport(layout = grid.layout(2, 1)))
print(myplot1, vp = viewport(layout.pos.row = 1, layout.pos.col = 1))
print(myplot2, vp = viewport(layout.pos.row = 2, layout.pos.col = 1))
print("goodbye Greg...leaving R")
q()